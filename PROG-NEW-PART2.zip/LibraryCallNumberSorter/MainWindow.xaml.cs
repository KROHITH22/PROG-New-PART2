﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace LibraryCallNumberSorter
{
    public partial class MainWindow : Window
    {
        private List<string> callNumbers;
        private List<Question> questions;
        private int currentQuestionIndex;
        private bool matchingDescriptions;
        private string _draggedItem;

        public MainWindow()
        {
            InitializeComponent();
            CallNumberListBox.Visibility = Visibility.Hidden;
            UserInputListBox.Visibility = Visibility.Hidden;
            CheckOrderButton.Visibility = Visibility.Hidden;

            // Initialize questions for Identifying areas task
            InitializeQuestions();

            // Display the first question
            DisplayQuestion();
        }

        private void InitializeQuestions()
        {
            questions = new List<Question>();

            // Generate 10 random call numbers for sorting task
            callNumbers = GenerateRandomCallNumbers(10);

            // Generate questions for Identifying areas task
            for (int i = 0; i < 10; i++)
            {
                List<string> options = GenerateRandomCallNumbers(4);
                options.Add(callNumbers[i]); // Add the correct answer to options
                options = options.OrderBy(_ => Guid.NewGuid()).ToList(); // Shuffle options

                Question question = new Question
                {
                    CallNumber = callNumbers[i],
                    Options = options,
                };

                questions.Add(question);
            }
        }

        private void DisplayQuestion()
        {
            // Display the current question in the UI
            Question currentQuestion = questions[currentQuestionIndex];

            CallNumberListBox.ItemsSource = new List<string> { currentQuestion.CallNumber };

            if (matchingDescriptions)
            {
                UserInputListBox.ItemsSource = currentQuestion.Options;
            }
            else
            {
                UserInputListBox.ItemsSource = callNumbers;
            }
        }

        private void ReplacingBooks_Click(object sender, RoutedEventArgs e)
        {
            // Enable the sorting task and disable other tasks
            EnableSortingTask();

            matchingDescriptions = false; // Set to false for sorting task
            DisplayQuestion(); // Display the first question for sorting task
        }

        private void IdentifyingAreas_Click(object sender, RoutedEventArgs e)
        {
            // Enable the Identifying areas task and disable other tasks
            EnableIdentifyingAreasTask();

            matchingDescriptions = true; // Set to true for Identifying areas task
            DisplayQuestion(); // Display the first question for Identifying areas task
        }

        private void EnableSortingTask()
        {
            // Enable sorting task button and disable others
            foreach (UIElement element in rb_stackpanel.Children)
            {
                if (element is Button button)
                {
                    if (button.Content.ToString() == "Replacing Books")
                    {
                        button.IsEnabled = false;
                    }
                    else
                    {
                        button.IsEnabled = true;
                    }
                }
            }
            UserInputListBox.Items.Clear();
        }

        private void EnableIdentifyingAreasTask()
        {
            // Enable Identifying areas task button and disable others
            foreach (UIElement element in rb_stackpanel.Children)
            {
                if (element is Button button)
                {
                    if (button.Content.ToString() == "Identifying Areas")
                    {
                        button.IsEnabled = false;
                    }
                    else
                    {
                        button.IsEnabled = true;
                    }
                }
            }
            UserInputListBox.Items.Clear();
        }

        private List<string> GenerateRandomCallNumbers(int count)
        {
            List<string> randomCallNumbers = new List<string>();
            Random rand = new Random();

            for (int i = 0; i < count; i++)
            {
                int topicNumber = rand.Next(1000, 9999);
                string authorLetters = GetRandomLetters(3);

                randomCallNumbers.Add($"{topicNumber / 100}.{topicNumber % 100} {authorLetters}");
            }

            return randomCallNumbers;
        }

        private string GetRandomLetters(int count)
        {
            Random rand = new Random();
            const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            return new string(Enumerable.Repeat(alphabet, count)
                .Select(s => s[rand.Next(s.Length)]).ToArray());
        }

        private void ListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var listBox = sender as ListBox;
            var item = ((FrameworkElement)e.OriginalSource).DataContext as string;
            if (item != null)
            {
                _draggedItem = item;
                DragDrop.DoDragDrop(listBox, _draggedItem, DragDropEffects.Move);
            }
        }

        private void ListBox_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.Move;
            e.Handled = true;
        }

        private void ListBox_Drop(object sender, DragEventArgs e)
        {
            if (_draggedItem != null)
            {
                var listBox = sender as ListBox;

                // Remove the dragged item from BOTH list boxes
                CallNumberListBox.Items.Remove(_draggedItem);
                UserInputListBox.Items.Remove(_draggedItem);

                // add to the target list box
                listBox.Items.Add(_draggedItem);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (UserInputListBox.Items.Count < 10)
            {
                MessageBox.Show("Please drag all numbers across and arrange them.");
                return;
            }

            List<string> userInputList = new List<string>();
            foreach (var item in UserInputListBox.Items)
            {
                userInputList.Add(item.ToString());
            }

            // Sort the list
            userInputList.Sort();
            int wrongCount = 0;

            for (int i = 0; i < UserInputListBox.Items.Count; i++)
            {
                if (!UserInputListBox.Items[i].ToString().Equals(userInputList[i]))
                {
                    wrongCount++;
                }
            }

            if (wrongCount == 0)
            {
                MessageBox.Show("Correct!", "Congratulations");
            }
            else
            {
                MessageBox.Show($"{wrongCount} call numbers are out of order");
            }

            // Move to the next question
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.Count)
            {
                DisplayQuestion();
            }
            else
            {
                MessageBox.Show("Task Completed! You answered all questions.");
                EnableSortingTask(); // Enable sorting task button after completing Identifying areas task
            }
        }

        private class Question
        {
            public string CallNumber { get; set; }
            public List<string> Options { get; set; }
        }
    }
}
